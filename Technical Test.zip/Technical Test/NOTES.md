# NOTES

## Supuestos

### Parte 1: Build desde Figma
- **El frame Light Desktop no tiene el botón "Complete today's Daily"**, pero los otros tres frames sí. Lo dejé en los cuatro porque parece una omisión del diseño; lo confirmaría con el diseñador. Ocultarlo solo en light desktop también lo ocultaría en los clientes que no soportan media queries.
- **YouTube no aparece en los frames Mobile** (a 340px caben 6 íconos), así que lo oculto en móvil.
- En los frames Mobile **el nav del footer va en dos filas** aunque cabría en una, así que lo forcé en móvil.
- **Fuentes:** Archivo (condensada en títulos y nav, normal en texto, expandida en botones) y JetBrains Mono en subtítulos. Las identifiqué comparando contra los frames; las confirmaría en Dev Mode.
- **Imágenes:** recortadas de los exports 1x de los frames para que coincidan exactamente con el diseño. Para producción las reexportaría a 2x desde Figma con los mismos nombres y las subiría al CDN/ESP con URLs absolutas.
- **Fondo exterior** en `#CCCCCC` (fuera del contenedor de 600px) para que el email no se pierda contra el header en pantallas anchas.
- Los links apuntan al sitio de la marca; las URLs reales con tracking vendrían del brief.

### Parte 2: Template dinámico (AMPscript)
- **Cliente y catálogo simulados** como strings JSON leídos con `BuildRowsetFromJSON`. En producción el cliente vendría de la Data Extension de envío (`AttributeValue`) y el catálogo de una Data Extension con `offer_id` como llave primaria, consultada con `LookupRows`.
- **"Usada" significa mostrada.** Si un small-callout se oculta por no llegar a 3, sus ofertas no cuentan como usadas y un bloque posterior todavía puede mostrarlas.
- **Los disclaimers se deduplican por texto**, después de reemplazar `{community_name}`. Como el `==` de AMPscript no distingue mayúsculas, dos textos que solo difieren en eso cuentan como iguales. Si legal prefiere una línea por comercio, el cambio es comparar la línea completa.
- **El offer code** se muestra en cualquier tipo de tarjeta cuando existe (el HTML estático solo lo mostraba en una tarjeta grande, pero la regla del brief es general).
- **El alt del promo** usa el nombre del comercio, como dice el brief.
- **El redondeo del ahorro** es hacia arriba en .5 y explícito (`floor(x + 0.5)`), para que 1250.5 dé `$1,251` sin depender del formateador. Si queda en 0, el link se oculta.
- Un string con solo espacios cuenta como vacío, y un tipo de bloque desconocido se ignora sin romper el email.
- Dos URLs del catálogo traen `&` y `"`. Las escapo para que el HTML sea válido, pero deberían venir URL-encoded desde datos; lo reportaría al equipo de datos.

## Dónde usé herramientas de IA

Usé Claude.

- **Investigación de documentación (el uso principal).** Lo usé sobre todo para buscar y contrastar la documentación oficial de Salesforce Marketing Cloud antes de escribir AMPscript:
  - `BuildRowsetFromJSON`: confirmé que corre al momento del envío, que los arrays de valores devuelven una columna `Value`, que no soporta filtros JSONPath y que un objeto solo hay que envolverlo en `[]`.
  - El índice de funciones: confirmé que **AMPscript no tiene una función para escapar HTML**, lo que definió que escapara con `Replace` anidados.
  - `Field()` con su tercer parámetro (vacío en vez de error si el campo no existe), `BuildRowsetFromString` (columna sin nombre, por posición), `FormatNumber` y `Mod` con decimales.
  - También para técnicas de email: VML en Outlook, selectores de dark mode de Outlook.com (`data-ogsc` / `data-ogsb`) y el patrón fluid hybrid.

## Qué haría a continuación
1. Confirmar fuentes y tamaños en Dev Mode y cambiar las imágenes por exports 2x (mismos nombres de archivo).
2. Pasar ambos emails por Litmus / Email on Acid: Outlook 2016/2019/365 en Windows, nuevo Outlook, Outlook.com en dark, Gmail web/iOS/Android, Apple Mail light/dark y Samsung Mail. Las capturas incluidas son renders locales en Chromium.
3. Parte 2: preview y test send en SFMC, cambiar los mocks por los atributos de la DE de envío y `LookupRows` sobre la DE del catálogo, y acordar con el equipo los supuestos de "usada" y de deduplicación de disclaimers.
4. Revisión de accesibilidad con lector de pantalla (orden de lectura de columnas apiladas, textos de links).
5. Automatizar las pruebas del template para validar cambios de config o catálogo antes de cada envío.
